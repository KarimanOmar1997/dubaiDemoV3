import React, { useEffect, useRef, useState, useCallback } from "react";
import ChatPanel from "./components/ChatPanel";
import MapPanel from "./components/MapPanel";
import { useLeaflet } from "./hooks/useLeaflet";
import { useGeoData } from "./hooks/useGeoData";
import { useMapActions } from "./hooks/useMapActions";
import { useChat } from "./hooks/useChat";

export default function EnhancedGeoChatBotApp() {
  const mapDiv = useRef(null);
  const mapRef = useRef(null);
  const geoJsonLayerRef = useRef(null);
  const highlightLayerRef = useRef(null);
  const legendRef = useRef(null);
  const processedActionsRef = useRef(new Set());

  const [mapStats, setMapStats] = useState({ zoom: 8, features: 0 });

  const {
    availableFiles,
    allFeaturesData,
    connectionStatus,
    setConnectionStatus,
    dataProcessingStatus,
    loadGeoJSONFiles,
    activeFeatures,
    setActiveFeatures
  } = useGeoData();

  const { leafletLoaded } = useLeaflet(setConnectionStatus);

  const {
    messages,
    addMessage,
    isTyping,
    setIsTyping,
    input,
    setInput,
    loading,
    setLoading,
    setMessages
  } = useChat();

  const {
    findClosestIncidents,
    displayOnlyFeatures,
    handleMapAction,
    parseDate,
    calculateDistance,
    createHeatmap,
    analyzeHighSeverityIncidents
  } = useMapActions({
    allFeaturesData,
    mapRef,
    geoJsonLayerRef,
    highlightLayerRef,
    legendRef,
    processedActionsRef,
    addMessage,
    setActiveFeatures
  });

  // Clear chat function
  const clearChat = useCallback(() => {
    setMessages([{
      id: 1,
      sender: "bot",
      text: "مرحباً بك في StrategizeIT! 🗺️ أنا مساعدك الذكي للخرائط. جاري تحميل البيانات من الخادم...",
      timestamp: new Date(),
    }]);

    if (highlightLayerRef.current) {
      mapRef.current?.removeLayer(highlightLayerRef.current);
      highlightLayerRef.current = null;
    }
    if (geoJsonLayerRef.current) {
      mapRef.current?.removeLayer(geoJsonLayerRef.current);
      geoJsonLayerRef.current = null;
    }
    if (legendRef.current) {
      mapRef.current?.removeControl(legendRef.current);
      legendRef.current = null;
    }
    setActiveFeatures(0);
    processedActionsRef.current.clear();

    // Reload data
    if (leafletLoaded && mapRef.current) {
      loadGeoJSONFiles();
    }
  }, [setMessages, setActiveFeatures, leafletLoaded, loadGeoJSONFiles]);

  // Initialize map
  useEffect(() => {
    if (!leafletLoaded || !mapDiv.current || mapRef.current) return;

    try {
      const map = window.L.map(mapDiv.current, {
        center: [25.267078, 55.293646], // Dubai coordinates
        zoom: 14,
        zoomControl: true,
        layers: [],
      });

      window.L.tileLayer(
        "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
        {
          attribution: "Tiles © Esri",
          maxZoom: 18,
        }
      ).addTo(map);

      mapRef.current = map;

      // Enhanced map click handler for proximity search
      map.on("zoomend", function () {
        setMapStats((prev) => ({ ...prev, zoom: map.getZoom() }));
      });

      console.log("✅ Map initialized successfully");
    } catch (error) {
      console.error("Map initialization failed:", error);
      setConnectionStatus("error");
      addMessage("bot", "⚠️ فشل في تهيئة الخريطة. يرجى إعادة تحميل الصفحة.");
    }
  }, [leafletLoaded, setConnectionStatus, addMessage]);

  // Add map click handler after data is loaded
  useEffect(() => {
    if (mapRef.current && allFeaturesData.length > 0) {
      const map = mapRef.current;

      // Remove any existing click handlers
      map.off('click');

      // Add new click handler
      map.on("click", async function (e) {
        const lat = e.latlng.lat;
        const lng = e.latlng.lng;

        console.log(`🖱️ Map clicked at coordinates: ${lat}, ${lng}`);
        console.log(`📊 Available features for search: ${allFeaturesData.length}`);

        addMessage("user", `أقرب 5 حوادث للإحداثيات: ${lat.toFixed(6)}, ${lng.toFixed(6)}`);

        // Call handleMapAction directly with current data
        try {
          await handleMapAction({
            action: "find-closest-spatial",
            lat: lat,
            lon: lng,
            limit: 5
          }, `click_${Date.now()}`);
        } catch (error) {
          console.error("Error in map click handler:", error);
          addMessage("bot", "❌ حدث خطأ أثناء البحث");
        }
      });

      console.log("✅ Map click handler added with data available");
    }
  }, [allFeaturesData, handleMapAction, addMessage]);

  // Load data when map is ready
  useEffect(() => {
    if (leafletLoaded && mapRef.current) {
      loadGeoJSONFiles();
    }
  }, [leafletLoaded, loadGeoJSONFiles]);

  // Enhanced handle user query function with high-severity analysis
  const handleUserQuery = useCallback(
    async (prompt) => {
      if (!prompt.trim()) return;

      processedActionsRef.current.clear();

      addMessage("user", prompt);
      setInput("");
      setLoading(true);
      setIsTyping(true);

      // Simulate thinking time
      await new Promise(resolve => setTimeout(resolve, 800));

      try {
        const lowerPrompt = prompt.toLowerCase().trim();
        console.log("🔍 Processing query:", lowerPrompt);
        console.log("📊 Available features:", allFeaturesData.length);

        // NEW: HIGH-SEVERITY INCIDENT ANALYSIS
        const severityKeywords = [
          "خطورة عالية", "حوادث خطيرة", "أكثر خطورة", "الأخطر",
          "حوادث قاتلة", "وفيات", "إصابات شديدة", "أشد الحوادث",
          "high severity", "dangerous", "fatal", "critical", "severe"
        ];
        const hasSeverityKeyword = severityKeywords.some(keyword => lowerPrompt.includes(keyword));

        if (hasSeverityKeyword) {
          setIsTyping(false);
          addMessage("bot", "🚨 جاري تحليل الحوادث عالية الخطورة وتحديد أكثر المناطق خطورة...");

          await handleMapAction({
            action: "analyze-high-severity"
          }, `query_severity_${Date.now()}`);

          return;
        }

        // HEATMAP/DENSITY ANALYSIS
        const heatmapKeywords = ["heatmap", "كثافة", "تمركز", "تجمع", "تركز", "خريطة حرارية", "حرارية"];
        const hasHeatmapKeyword = heatmapKeywords.some(keyword => lowerPrompt.includes(keyword));

        if (hasHeatmapKeyword) {
          setIsTyping(false);
          addMessage("bot", "🔥 جاري تحليل كثافة الحوادث وإنشاء الخريطة الحرارية...");

          await handleMapAction({
            action: "create-heatmap",
            intensity: 0.6,
            radius: 30
          }, `query_heatmap_${Date.now()}`);

          return;
        }

        // Enhanced coordinate parsing - support various formats
        const coordPatterns = [
          /(\d+\.?\d*)[,\s]+(\d+\.?\d*)/,
          /lat[:\s]*(\d+\.?\d*)[,\s]*lon[:\s]*(\d+\.?\d*)/i,
          /(\d+\.?\d*)\s*درجة[,\s]*(\d+\.?\d*)\s*درجة/,
          /إحداثيات[:\s]*(\d+\.?\d*)[,\s]*(\d+\.?\d*)/
        ];

        let coordMatch = null;
        for (const pattern of coordPatterns) {
          coordMatch = prompt.match(pattern);
          if (coordMatch) break;
        }

        // Check for proximity/closest search keywords
        const proximityKeywords = ["أقرب", "قريب", "closest", "near", "بالقرب"];
        const hasProximityKeyword = proximityKeywords.some(keyword => lowerPrompt.includes(keyword));

        // Extract number limit
        const limitMatch = prompt.match(/(\d+)\s*حوادث?|(\d+)\s*incidents?/i);
        const limit = limitMatch ? parseInt(limitMatch[1] || limitMatch[2]) : 5;

        // SPATIAL SEARCH - with coordinates
        if (hasProximityKeyword && coordMatch) {
          const lat = parseFloat(coordMatch[1]);
          const lon = parseFloat(coordMatch[2]);

          console.log(`🎯 Extracted coordinates: ${lat}, ${lon}, limit: ${limit}`);

          if (lat && lon && lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180) {
            if (allFeaturesData.length > 0) {
              setIsTyping(false);
              addMessage("bot", `🎯 تم تحليل طلبك! جاري البحث عن ${limit} حوادث أقرب للإحداثيات (${lat.toFixed(6)}, ${lon.toFixed(6)})`);

              await handleMapAction({
                action: "find-closest-spatial",
                lat: lat,
                lon: lon,
                limit: limit
              }, `query_coords_${Date.now()}`);

              return;
            } else {
              setIsTyping(false);
              addMessage("bot", "⚠️ البيانات غير محملة بعد. يرجى انتظار اكتمال التحميل.");
              return;
            }
          } else {
            setIsTyping(false);
            addMessage("bot", "⚠️ الإحداثيات غير صحيحة. تأكد من أن خط العرض بين -90 و 90 وخط الطول بين -180 و 180");
            return;
          }
        }

        // SPATIAL SEARCH - with location names (dynamic based on data)
        if (hasProximityKeyword && (lowerPrompt.includes("حادث") || lowerPrompt.includes("incident"))) {
          // Remove static location mappings - will search dynamically in the loaded data
          const searchTerm = lowerPrompt.replace(/أقرب|حادث|حوادث|closest|incident/g, '').trim();

          if (searchTerm) {
            setIsTyping(false);
            addMessage("bot", `🔍 جاري البحث عن المنطقة "${searchTerm}" في البيانات المحملة...`);

            // Search for features matching the location name
            const matchingFeatures = allFeaturesData.filter(feature => {
              const props = feature.properties || {};
              return Object.values(props).some(value =>
                String(value).toLowerCase().includes(searchTerm)
              );
            });

            if (matchingFeatures.length > 0) {
              // Use first matching feature's coordinates as center
              const centerFeature = matchingFeatures[0];
              let lat = null, lon = null;

              if (centerFeature.geometry?.type === 'Point') {
                [lon, lat] = centerFeature.geometry.coordinates;
              } else if (centerFeature.geometry?.type === 'Polygon') {
                const coords = centerFeature.geometry.coordinates[0];
                lat = coords.reduce((sum, coord) => sum + coord[1], 0) / coords.length;
                lon = coords.reduce((sum, coord) => sum + coord[0], 0) / coords.length;
              }

              if (lat && lon) {
                await handleMapAction({
                  action: "find-closest-spatial",
                  lat: lat,
                  lon: lon,
                  limit: limit
                }, `query_location_search_${Date.now()}`);

                return;
              }
            } else {
              setIsTyping(false);
              addMessage("bot", `⚠️ لم يتم العثور على "${searchTerm}" في البيانات المحملة.\n\n💡 جرب البحث بالإحداثيات أو انقر على الخريطة مباشرة.`);
              return;
            }
          }
        }

        // TEMPORAL SEARCH
        if (lowerPrompt.includes("زمنياً") || lowerPrompt.includes("تاريخ") || lowerPrompt.includes("temporal") || lowerPrompt.includes("date")) {
          const datePatterns = [
            /(\d{4}[-/]\d{1,2}[-/]\d{1,2})/,
            /(\d{1,2}[-/]\d{1,2}[-/]\d{4})/,
            /تاريخ[:\s]*(\d{4}[-/]\d{1,2}[-/]\d{1,2})/,
            /date[:\s]*(\d{4}[-/]\d{1,2}[-/]\d{1,2})/i
          ];

          let dateMatch = null;
          for (const pattern of datePatterns) {
            dateMatch = prompt.match(pattern);
            if (dateMatch) break;
          }

          if (dateMatch) {
            setIsTyping(false);
            addMessage("bot", `⏰ جاري البحث عن أقرب ${limit} حوادث زمنياً لتاريخ ${dateMatch[1]}`);

            await handleMapAction({
              action: "find-closest-temporal",
              date: dateMatch[1],
              limit: limit
            }, `query_temporal_${Date.now()}`);

            return;
          } else {
            setIsTyping(false);
            addMessage("bot", "⚠️ لم أتمكن من تحديد التاريخ. استخدم صيغ مثل: 2024-01-15 أو 15/01/2024");
            return;
          }
        }
        // CLEAR/RESET
        if (lowerPrompt.includes("مسح") || lowerPrompt.includes("clear") || lowerPrompt.includes("reset") || lowerPrompt.includes("نظف")) {
          setIsTyping(false);
          addMessage("bot", "🧹 جاري مسح جميع النتائج من الخريطة...");

          await handleMapAction({
            action: "clear"
          }, `query_clear_${Date.now()}`);

          return;
        }

        // HELP/INFO
        if (lowerPrompt.includes("مساعدة") || lowerPrompt.includes("help") || lowerPrompt.includes("كيف") || lowerPrompt.includes("how")) {
          setIsTyping(false);
          addMessage("bot", `🤖 **مرحباً! إليك ما يمكنني مساعدتك به:**\n\n🚨 **تحليل الحوادث عالية الخطورة:**\n• "أين توجد أكثر الأحداث ذات خطورة عالية"\n• "الحوادث القاتلة في المنطقة"\n• "تحليل الحوادث الخطيرة"\n\n🎯 **البحث المكاني (بالإحداثيات):**\n• "أقرب 5 حوادث للإحداثيات 25.267699, 55.294676"\n• "أقرب 10 حوادث لـ 25.2048, 55.2708"\n\n🏙️ **البحث المكاني (بأسماء الأماكن):**\n• "أقرب حادث لدبي"\n• "أقرب 3 حوادث للراس"\n• "أقرب حوادث لديرة"\n\n⏰ **البحث الزمني:**\n• "أقرب حوادث زمنياً لتاريخ 2024-12-30"\n• "أقرب 7 حوادث لتاريخ 15/01/2024"\n\n🔥 **الخريطة الحرارية:**\n• "أين تمركز أكثر الحوادث"\n• "خريطة حرارية للكثافة"\n• "تحليل الكثافة"\n\n🧹 **أوامر أخرى:**\n• "مسح الخريطة" - لإزالة النتائج\n• "إحصائيات"\n\n💡 أو انقر مباشرة على الخريطة للبحث السريع!`);
          return;
        }

        // STATS/INFO
        if (lowerPrompt.includes("إحصائيات") || lowerPrompt.includes("stats") || lowerPrompt.includes("معلومات") || lowerPrompt.includes("info")) {
          setIsTyping(false);
          const totalFeatures = allFeaturesData.length;
          const filesCount = availableFiles.length;
          const displayedFeatures = activeFeatures;

          addMessage("bot", `📊 **إحصائيات البيانات الحالية:**\n\n📁 عدد الملفات المحملة: ${filesCount}\n📍 إجمالي الحوادث: ${totalFeatures.toLocaleString()}\n📍 المعروض حالياً: ${displayedFeatures}\n🗺️ مستوى التكبير: ${mapStats.zoom}\n\n✅ حالة النظام: ${dataProcessingStatus === "completed" ? "جاهز للاستخدام" : "قيد التحميل"}\n\n💡 جرب النقر على الخريطة أو كتابة استعلام للبدء!`);
          return;
        }

        // If we reach here, the query wasn't understood
        setIsTyping(false);
        addMessage("bot", `🤔 لم أتمكن من فهم طلبك: "${prompt}"\n\n✨ **جرب هذه الأمثلة:**\n\n🚨 **للحوادث عالية الخطورة:**\n• "أين توجد أكثر الأحداث ذات خطورة عالية"\n• "الحوادث القاتلة"\n• "تحليل الحوادث الخطيرة"\n\n🎯 **للبحث المكاني:**\n• "أقرب 5 حوادث للإحداثيات 25.267699, 55.294676"\n• "أقرب حادث لدبي"\n\n⏰ **للبحث الزمني:**\n• "أقرب حوادث زمنياً لتاريخ 2024-12-30"\n\n🔥 **للخريطة الحرارية:**\n• "أين تمركز أكثر الحوادث"\n• "خريطة حرارية"\n\n🧹 **أوامر أخرى:**\n• "مسح الخريطة"\n• "مساعدة"\n• "إحصائيات"\n\n💡 أو انقر مباشرة على الخريطة للبحث السريع!`);

      } catch (error) {
        console.error("Query processing error:", error);
        setIsTyping(false);
        addMessage("bot", `🔧 حدث خطأ في معالجة طلبك: ${error.message}\n\n💡 يرجى المحاولة مرة أخرى أو النقر على الخريطة للبحث المباشر.`);
      } finally {
        setLoading(false);
        setIsTyping(false);
      }
    },
    [handleMapAction, parseDate, allFeaturesData, availableFiles, activeFeatures, mapStats, dataProcessingStatus, addMessage, setLoading, setIsTyping, setInput]
  );

  // Monitor allFeaturesData changes
  useEffect(() => {
    console.log("📈 عدد الميزات المتاحة:", allFeaturesData.length);
    if (allFeaturesData.length > 0) {
      setMapStats(prev => ({ ...prev, features: allFeaturesData.length }));
    }
  }, [allFeaturesData]);

  // Monitor connection status
  useEffect(() => {
    console.log("🔗 حالة الاتصال:", connectionStatus);
  }, [connectionStatus]);

  // Monitor data processing status
  useEffect(() => {
    console.log("⚙️ حالة معالجة البيانات:", dataProcessingStatus);
  }, [dataProcessingStatus]);

  return (
    <div className="flex h-screen bg-gray-50">
      <ChatPanel
        messages={messages}
        input={input}
        setInput={setInput}
        loading={loading}
        connectionStatus={connectionStatus}
        activeFeatures={activeFeatures}
        mapStats={mapStats}
        dataProcessingStatus={dataProcessingStatus}
        handleUserQuery={handleUserQuery}
        clearChat={clearChat}
        isTyping={isTyping}
      />
      <MapPanel
        mapDiv={mapDiv}
        leafletLoaded={leafletLoaded}
        allFeaturesData={allFeaturesData}
        handleMapAction={handleMapAction}
        availableFiles={availableFiles}
        activeFeatures={activeFeatures}
        dataProcessingStatus={dataProcessingStatus}
        mapStats={mapStats}
      />
    </div>
  );
}