import { useCallback } from "react";

export const useMapActions = ({
  allFeaturesData,
  mapRef,
  geoJsonLayerRef,
  highlightLayerRef,
  legendRef,
  processedActionsRef,
  addMessage,
  setActiveFeatures,
}) => {
  // Enhanced function to calculate distance between two coordinates
  const calculateDistance = useCallback((lat1, lon1, lat2, lon2) => {
    const R = 6371; // Radius of Earth in kilometers
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }, []);

  // Enhanced function to parse dates from various formats
  const parseDate = useCallback((dateStr) => {
    if (!dateStr) return null;

    try {
      // If it's a timestamp
      if (typeof dateStr === "number") {
        return new Date(dateStr);
      }

      const date = new Date(dateStr);
      if (!isNaN(date.getTime())) {
        return date;
      }
    } catch (e) {
      console.warn("Could not parse date:", dateStr);
    }
    return null;
  }, []);

  // NEW: Analyze high-severity incidents and their geographic distribution
  const analyzeHighSeverityIncidents = useCallback(async () => {
    if (!mapRef.current || !window.L || !allFeaturesData.length) {
      console.log("❌ Cannot analyze: missing map, Leaflet, or data");
      return;
    }

    const L = window.L;

    try {
      // Remove existing layers
      if (geoJsonLayerRef.current) {
        mapRef.current.removeLayer(geoJsonLayerRef.current);
        geoJsonLayerRef.current = null;
      }
      if (highlightLayerRef.current) {
        mapRef.current.removeLayer(highlightLayerRef.current);
        highlightLayerRef.current = null;
      }

      // Filter high-severity incidents
      const highSeverityIncidents = allFeaturesData.filter((feature) => {
        const props = feature.properties || {};

        // Check various severity indicators
        const severity = (
          props.Severity_Ar ||
          props.Severity ||
          ""
        ).toLowerCase();
        const type = (props.Type_Ar || props.Type || "").toLowerCase();
        const accName = (props.Acc_Name || "").toLowerCase();

        // High severity keywords in Arabic and English
        const highSeverityKeywords = [
          "خطير",
          "شديد",
          "قاتل",
          "وفاة",
          "قتل",
          "جسيم",
          "بليغ",
          "severe",
          "fatal",
          "critical",
          "death",
          "serious",
          "major",
        ];

        return highSeverityKeywords.some(
          (keyword) =>
            severity.includes(keyword) ||
            type.includes(keyword) ||
            accName.includes(keyword)
        );
      });

      console.log(
        `🔥 Found ${highSeverityIncidents.length} high-severity incidents`
      );

      if (highSeverityIncidents.length === 0) {
        addMessage(
          "bot",
          "⚠️ لم يتم العثور على حوادث ذات خطورة عالية في البيانات المحملة"
        );
        return;
      }

      // Geographic clustering analysis
      const clusters = performGeographicClustering(highSeverityIncidents);

      // Create individual markers for high-severity incidents
      const processedIncidents = [];
      const markersGroup = L.layerGroup();

      highSeverityIncidents.forEach((feature, index) => {
        let lat = null,
          lon = null;

        if (feature.geometry) {
          switch (feature.geometry.type) {
            case "Point":
              [lon, lat] = feature.geometry.coordinates;
              break;
            case "Polygon":
            case "MultiPolygon":
              const coords =
                feature.geometry.type === "Polygon"
                  ? feature.geometry.coordinates[0]
                  : feature.geometry.coordinates[0][0];
              lat =
                coords.reduce((sum, coord) => sum + coord[1], 0) /
                coords.length;
              lon =
                coords.reduce((sum, coord) => sum + coord[0], 0) /
                coords.length;
              break;
          }
        }

        if (lat !== null && lon !== null) {
          const props = feature.properties || {};

          // Determine severity level and marker style
          let severityLevel = "moderate";
          let markerColor = "#ff9800";
          let markerSize = 8;

          if (
            (props.Severity_Ar || "").toLowerCase().includes("قاتل") ||
            (props.Type_Ar || "").toLowerCase().includes("وفاة")
          ) {
            severityLevel = "fatal";
            markerColor = "#b71c1c";
            markerSize = 12;
          } else if ((props.Severity_Ar || "").toLowerCase().includes("شديد")) {
            severityLevel = "severe";
            markerColor = "#d32f2f";
            markerSize = 10;
          } else if ((props.Severity_Ar || "").toLowerCase().includes("خطير")) {
            severityLevel = "serious";
            markerColor = "#f44336";
            markerSize = 9;
          }

          // Create custom marker
          const marker = L.circleMarker([lat, lon], {
            radius: markerSize,
            fillColor: markerColor,
            color: "#ffffff",
            weight: 2,
            opacity: 1,
            fillOpacity: 0.8,
            className: `severity-marker ${severityLevel}`,
          });

          // Create popup with incident details
          const popupContent = `
          <div style="font-family: Arial, sans-serif; direction: rtl; text-align: right;">
            <h4 style="margin: 0 0 10px 0; color: ${markerColor}; font-size: 14px;">
              🚨 حادث عالي الخطورة
            </h4>
            <div style="font-size: 12px; line-height: 1.4;">
              <strong>النوع:</strong> ${props.Type_Ar || props.Type || "غير محدد"
            }<br>
              <strong>الخطورة:</strong> ${props.Severity_Ar || props.Severity || "غير محدد"
            }<br>
              ${props.Acc_Name
              ? `<strong>اسم الحادث:</strong> ${props.Acc_Name}<br>`
              : ""
            }
              ${props.Location
              ? `<strong>الموقع:</strong> ${props.Location}<br>`
              : ""
            }
              ${props.Date ? `<strong>التاريخ:</strong> ${props.Date}<br>` : ""}
              ${props.Time ? `<strong>الوقت:</strong> ${props.Time}<br>` : ""}
            </div>
            <div style="margin-top: 8px; padding-top: 8px; border-top: 1px solid #eee; font-size: 10px; color: #666;">
              الإحداثيات: ${lat.toFixed(6)}, ${lon.toFixed(6)}
            </div>
          </div>
        `;

          marker.bindPopup(popupContent, {
            maxWidth: 300,
            className: "severity-popup",
          });

          // Add hover effects
          marker.on("mouseover", function (e) {
            this.setStyle({
              radius: markerSize + 2,
              weight: 3,
            });
          });

          marker.on("mouseout", function (e) {
            this.setStyle({
              radius: markerSize,
              weight: 2,
            });
          });

          markersGroup.addLayer(marker);

          processedIncidents.push({
            feature,
            coordinates: [lat, lon],
            severityLevel,
            properties: props,
            marker,
          });
        }
      });

      // Add markers group to map
      highlightLayerRef.current = markersGroup;
      markersGroup.addTo(mapRef.current);

      // Create detailed legend for severity analysis
      const legend = L.control({ position: "bottomright" });
      legend.onAdd = function () {
        const div = L.DomUtil.create("div", "severity-legend");
        div.style.cssText = `
        background: white;
        padding: 12px;
        border-radius: 10px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        font-size: 12px;
        line-height: 1.5;
        max-width: 250px;
        border: 2px solid #d32f2f;
      `;

        div.innerHTML = `
        <div style="font-weight: bold; margin-bottom: 10px; text-align: center; color: #d32f2f; font-size: 14px;">
          🚨 تحليل الحوادث عالية الخطورة
        </div>
        <div style="margin-bottom: 8px;">
          <div style="display: flex; align-items: center; margin-bottom: 4px;">
            <div style="width: 12px; height: 12px; background: #b71c1c; border-radius: 50%; margin-left: 6px; border: 2px solid white;"></div>
            <span>حوادث قاتلة (${processedIncidents.filter((i) => i.severityLevel === "fatal")
            .length
          })</span>
          </div>
          <div style="display: flex; align-items: center; margin-bottom: 4px;">
            <div style="width: 10px; height: 10px; background: #d32f2f; border-radius: 50%; margin-left: 6px; border: 2px solid white;"></div>
            <span>إصابات شديدة (${processedIncidents.filter((i) => i.severityLevel === "severe")
            .length
          })</span>
          </div>
          <div style="display: flex; align-items: center; margin-bottom: 4px;">
            <div style="width: 9px; height: 9px; background: #f44336; border-radius: 50%; margin-left: 6px; border: 2px solid white;"></div>
            <span>حوادث خطيرة (${processedIncidents.filter((i) => i.severityLevel === "serious")
            .length
          })</span>
          </div>
          <div style="display: flex; align-items: center;">
            <div style="width: 8px; height: 8px; background: #ff9800; border-radius: 50%; margin-left: 6px; border: 2px solid white;"></div>
            <span>خطورة متوسطة-عالية (${processedIncidents.filter((i) => i.severityLevel === "moderate")
            .length
          })</span>
          </div>
        </div>
        <div style="font-size: 10px; color: #666; margin-top: 10px; text-align: center; border-top: 1px solid #eee; padding-top: 8px;">
          إجمالي الحوادث: ${processedIncidents.length}
        </div>
      `;
        return div;
      };

      if (legendRef.current) {
        mapRef.current.removeControl(legendRef.current);
      }
      legendRef.current = legend;
      legend.addTo(mapRef.current);

      setActiveFeatures(processedIncidents.length);

      // Generate detailed analysis report
      const analysisReport = generateSeverityAnalysisReport(
        clusters,
        processedIncidents
      );

      console.log("✅ High-severity analysis completed");

      addMessage(
        "bot",
        `🚨 **تحليل الحوادث عالية الخطورة مكتمل!**\n\n📊 **الإحصائيات:**\n• إجمالي الحوادث عالية الخطورة: ${highSeverityIncidents.length
        }\n• نسبة الحوادث الخطيرة: ${(
          (highSeverityIncidents.length / allFeaturesData.length) *
          100
        ).toFixed(1)}%\n\n🔴 **توزيع حسب الخطورة:**\n• قاتلة: ${processedIncidents.filter((i) => i.severityLevel === "fatal").length
        }\n• شديدة: ${processedIncidents.filter((i) => i.severityLevel === "severe").length
        }\n• خطيرة: ${processedIncidents.filter((i) => i.severityLevel === "serious").length
        }\n• متوسطة-عالية: ${processedIncidents.filter((i) => i.severityLevel === "moderate")
          .length
        }\n\n🏆 **أكثر المناطق خطورة:**\n${analysisReport.topDangerousAreas
        }\n\n📈 **توزيع أنواع الحوادث:**\n${analysisReport.severityDistribution
        }\n\n🎯 **التوصيات:**\n${analysisReport.recommendations
        }\n\n💡 انقر على النقاط للحصول على تفاصيل كل حادث.`
      );
    } catch (error) {
      console.error("Failed to analyze high-severity incidents:", error);
      addMessage(
        "bot",
        `❌ فشل في تحليل الحوادث عالية الخطورة: ${error.message}`
      );
    }
  }, [
    allFeaturesData,
    mapRef,
    geoJsonLayerRef,
    highlightLayerRef,
    legendRef,
    setActiveFeatures,
    addMessage,
  ]);

  // NEW: Geographic clustering for high-severity analysis
  const performGeographicClustering = useCallback((incidents) => {
    const gridSize = 0.008; // Smaller grid for more precise clustering (~800m)
    const clusters = {};

    incidents.forEach((feature) => {
      let lat = null,
        lon = null;

      if (feature.geometry) {
        switch (feature.geometry.type) {
          case "Point":
            [lon, lat] = feature.geometry.coordinates;
            break;
          case "Polygon":
            const coords = feature.geometry.coordinates[0];
            lat =
              coords.reduce((sum, coord) => sum + coord[1], 0) / coords.length;
            lon =
              coords.reduce((sum, coord) => sum + coord[0], 0) / coords.length;
            break;
        }
      }

      if (lat !== null && lon !== null) {
        const gridLat = Math.floor(lat / gridSize) * gridSize;
        const gridLon = Math.floor(lon / gridSize) * gridSize;
        const key = `${gridLat},${gridLon}`;

        if (!clusters[key]) {
          clusters[key] = {
            count: 0,
            fatalCount: 0,
            severeCount: 0,
            lat: gridLat,
            lon: gridLon,
            incidents: [],
            areas: new Set(),
          };
        }

        clusters[key].count++;
        clusters[key].incidents.push(feature);

        const props = feature.properties || {};
        const severity = (props.Severity_Ar || "").toLowerCase();
        const type = (props.Type_Ar || "").toLowerCase();

        if (
          severity.includes("قاتل") ||
          type.includes("وفاة") ||
          type.includes("قتل")
        ) {
          clusters[key].fatalCount++;
        } else if (severity.includes("شديد") || severity.includes("خطير")) {
          clusters[key].severeCount++;
        }

        // Track area names
        if (props.COMM_NAME_AR) {
          clusters[key].areas.add(props.COMM_NAME_AR);
        }
      }
    });

    return Object.values(clusters).sort(
      (a, b) =>
        b.fatalCount * 3 +
        b.severeCount * 2 +
        b.count -
        (a.fatalCount * 3 + a.severeCount * 2 + a.count)
    );
  }, []);

  // NEW: Generate detailed severity analysis report
  const generateSeverityAnalysisReport = useCallback((clusters, incidents) => {
    // Top dangerous areas
    const topAreas = clusters.slice(0, 5).map((cluster, index) => {
      const areaNames = Array.from(cluster.areas).slice(0, 2).join("، ");
      const riskScore =
        cluster.fatalCount * 3 + cluster.severeCount * 2 + cluster.count;
      return `${index + 1}. منطقة (${cluster.lat.toFixed(
        3
      )}, ${cluster.lon.toFixed(3)})\n   📍 ${areaNames || "منطقة غير محددة"
        }\n   💀 حوادث قاتلة: ${cluster.fatalCount}\n   🚨 حوادث شديدة: ${cluster.severeCount
        }\n   📊 نقاط الخطر: ${riskScore}`;
    });

    // Severity distribution analysis
    const severityStats = incidents.reduce(
      (acc, incident) => {
        const props = incident.properties;
        const severity = (props.Severity_Ar || "").toLowerCase();
        const type = (props.Type_Ar || "").toLowerCase();

        if (severity.includes("قاتل") || type.includes("وفاة")) {
          acc.fatal++;
        } else if (severity.includes("شديد")) {
          acc.severe++;
        } else if (severity.includes("خطير")) {
          acc.dangerous++;
        } else {
          acc.other++;
        }
        return acc;
      },
      { fatal: 0, severe: 0, dangerous: 0, other: 0 }
    );

    const severityDistribution = [
      `• الحوادث القاتلة: ${severityStats.fatal} (${(
        (severityStats.fatal / incidents.length) *
        100
      ).toFixed(1)}%)`,
      `• الإصابات الشديدة: ${severityStats.severe} (${(
        (severityStats.severe / incidents.length) *
        100
      ).toFixed(1)}%)`,
      `• الحوادث الخطيرة: ${severityStats.dangerous} (${(
        (severityStats.dangerous / incidents.length) *
        100
      ).toFixed(1)}%)`,
      `• أخرى: ${severityStats.other} (${(
        (severityStats.other / incidents.length) *
        100
      ).toFixed(1)}%)`,
    ].join("\n");

    // Generate recommendations based on analysis
    const recommendations = generateSafetyRecommendations(
      clusters,
      severityStats
    );

    return {
      topDangerousAreas:
        topAreas.length > 0
          ? topAreas.join("\n\n")
          : "لا توجد مناطق عالية الخطورة",
      severityDistribution,
      recommendations,
    };
  }, []);

  // NEW: Generate safety recommendations
  const generateSafetyRecommendations = useCallback(
    (clusters, severityStats) => {
      const recommendations = [];

      if (severityStats.fatal > 0) {
        recommendations.push("🚑 تكثيف دوريات الإسعاف في المناطق الحمراء");
      }

      if (clusters.length > 0 && clusters[0].count > 5) {
        recommendations.push("🚦 مراجعة إشارات المرور في المناطق عالية التركز");
      }

      if (severityStats.severe > severityStats.fatal * 2) {
        recommendations.push("🏥 تحسين أوقات استجابة الطوارئ");
      }

      recommendations.push("📈 تطبيق حملات توعية مرورية مكثفة");
      recommendations.push("🛣️ فحص حالة الطرق في المناطق الخطرة");

      return recommendations
        .slice(0, 4)
        .map((rec, i) => `${i + 1}. ${rec}`)
        .join("\n");
    },
    []
  );

  // Enhanced function to create heatmap visualization
  const createHeatmap = useCallback(
    async (intensity = 0.5, radius = 25) => {
      if (!mapRef.current || !window.L || !allFeaturesData.length) {
        console.log("❌ Cannot create heatmap: missing map, Leaflet, or data");
        return;
      }

      const L = window.L;

      try {
        // Remove existing layers
        if (geoJsonLayerRef.current) {
          mapRef.current.removeLayer(geoJsonLayerRef.current);
          geoJsonLayerRef.current = null;
        }
        if (highlightLayerRef.current) {
          mapRef.current.removeLayer(highlightLayerRef.current);
          highlightLayerRef.current = null;
        }

        // Load heatmap plugin if not available
        if (!L.heatLayer) {
          console.log("📄 Loading heatmap plugin...");
          addMessage("bot", "📄 جاري تحميل مكون الخريطة الحرارية...", {
            type: "system",
          });

          const script = document.createElement("script");
          script.src =
            "https://cdnjs.cloudflare.com/ajax/libs/leaflet.heat/0.2.0/leaflet-heat.js";

          await new Promise((resolve, reject) => {
            script.onload = resolve;
            script.onerror = reject;
            document.head.appendChild(script);
          });
        }

        // Prepare heatmap data points
        const heatmapData = [];
        const validIncidents = [];

        allFeaturesData.forEach((feature) => {
          let lat = null,
            lon = null;

          if (feature.geometry) {
            switch (feature.geometry.type) {
              case "Point":
                [lon, lat] = feature.geometry.coordinates;
                break;
              case "Polygon":
              case "MultiPolygon":
                const coords =
                  feature.geometry.type === "Polygon"
                    ? feature.geometry.coordinates[0]
                    : feature.geometry.coordinates[0][0];
                lat =
                  coords.reduce((sum, coord) => sum + coord[1], 0) /
                  coords.length;
                lon =
                  coords.reduce((sum, coord) => sum + coord[0], 0) /
                  coords.length;
                break;
            }
          }

          if (lat !== null && lon !== null) {
            // Add intensity based on incident severity or type
            let weight = 1;
            const props = feature.properties || {};

            // Adjust weight based on severity or type
            if (props.Severity_Ar) {
              const severity = props.Severity_Ar.toLowerCase();
              if (severity.includes("خطير") || severity.includes("شديد"))
                weight = 3;
              else if (severity.includes("متوسط")) weight = 2;
              else weight = 1;
            } else if (props.Type_Ar) {
              const type = props.Type_Ar.toLowerCase();
              if (type.includes("وفاة") || type.includes("قتل")) weight = 4;
              else if (type.includes("إصابة")) weight = 2;
              else weight = 1;
            }

            heatmapData.push([lat, lon, weight]);
            validIncidents.push(feature);
          }
        });

        console.log(
          `🔥 Creating heatmap with ${heatmapData.length} data points`
        );

        if (heatmapData.length === 0) {
          addMessage("bot", "⚠️ لا توجد بيانات صالحة لإنشاء الخريطة الحرارية");
          return;
        }

        // Create heatmap layer
        const heatmapLayer = L.heatLayer(heatmapData, {
          radius: radius,
          blur: 15,
          maxZoom: 18,
          max: 1.0,
          gradient: {
            0.4: "blue",
            0.65: "lime",
            0.8: "yellow",
            0.95: "orange",
            1.0: "red",
          },
        });

        // Store as highlight layer for consistency with other functions
        highlightLayerRef.current = heatmapLayer;
        heatmapLayer.addTo(mapRef.current);

        // Create legend for heatmap
        const legend = L.control({ position: "bottomright" });
        legend.onAdd = function () {
          const div = L.DomUtil.create("div", "heatmap-legend");
          div.style.cssText = `
          background: white;
          padding: 10px;
          border-radius: 8px;
          box-shadow: 0 2px 10px rgba(0,0,0,0.2);
          font-size: 12px;
          line-height: 1.4;
          max-width: 200px;
        `;

          div.innerHTML = `
          <div style="font-weight: bold; margin-bottom: 8px; text-align: center; color: #333;">
            🔥 خريطة الكثافة
          </div>
          <div style="margin-bottom: 6px;">
            <div style="display: flex; align-items: center; margin-bottom: 3px;">
              <div style="width: 12px; height: 12px; background: red; border-radius: 50%; margin-left: 5px;"></div>
              <span>كثافة عالية جداً</span>
            </div>
            <div style="display: flex; align-items: center; margin-bottom: 3px;">
              <div style="width: 12px; height: 12px; background: orange; border-radius: 50%; margin-left: 5px;"></div>
              <span>كثافة عالية</span>
            </div>
            <div style="display: flex; align-items: center; margin-bottom: 3px;">
              <div style="width: 12px; height: 12px; background: yellow; border-radius: 50%; margin-left: 5px;"></div>
              <span>كثافة متوسطة</span>
            </div>
            <div style="display: flex; align-items: center; margin-bottom: 3px;">
              <div style="width: 12px; height: 12px; background: lime; border-radius: 50%; margin-left: 5px;"></div>
              <span>كثافة منخفضة</span>
            </div>
            <div style="display: flex; align-items: center;">
              <div style="width: 12px; height: 12px; background: blue; border-radius: 50%; margin-left: 5px;"></div>
              <span>كثافة قليلة</span>
            </div>
          </div>
          <div style="font-size: 10px; color: #666; margin-top: 8px; text-align: center; border-top: 1px solid #eee; padding-top: 6px;">
            إجمالي النقاط: ${heatmapData.length}
          </div>
        `;
          return div;
        };

        if (legendRef.current) {
          mapRef.current.removeControl(legendRef.current);
        }
        legendRef.current = legend;
        legend.addTo(mapRef.current);

        setActiveFeatures(validIncidents.length);

        // Analyze density clusters
        const densityAnalysis = analyzeDensityClusters(heatmapData);

        console.log("✅ Heatmap created successfully");

        addMessage(
          "bot",
          `🔥 تم إنشاء الخريطة الحرارية بنجاح!\n\n📊 **تحليل الكثافة:**\n• إجمالي النقاط: ${heatmapData.length
          }\n• المناطق عالية الكثافة: ${densityAnalysis.highDensityAreas
          }\n• متوسط الكثافة: ${densityAnalysis.averageDensity.toFixed(
            2
          )}\n\n🎯 **المناطق الأكثر تركزاً:**\n${densityAnalysis.topAreas.join(
            "\n"
          )}\n\n💡 استخدم أزرار التحكم لتغيير شدة الألوان أو نصف قطر التأثير.`
        );
      } catch (error) {
        console.error("Failed to create heatmap:", error);
        addMessage("bot", `❌ فشل في إنشاء الخريطة الحرارية: ${error.message}`);
      }
    },
    [
      allFeaturesData,
      mapRef,
      geoJsonLayerRef,
      highlightLayerRef,
      legendRef,
      setActiveFeatures,
      addMessage,
    ]
  );

  // Analyze density clusters
  const analyzeDensityClusters = useCallback((heatmapData) => {
    const gridSize = 0.01; // Approximately 1km grid
    const clusters = {};

    heatmapData.forEach(([lat, lon, weight]) => {
      const gridLat = Math.floor(lat / gridSize) * gridSize;
      const gridLon = Math.floor(lon / gridSize) * gridSize;
      const key = `${gridLat},${gridLon}`;

      if (!clusters[key]) {
        clusters[key] = {
          count: 0,
          totalWeight: 0,
          lat: gridLat,
          lon: gridLon,
        };
      }
      clusters[key].count++;
      clusters[key].totalWeight += weight;
    });

    const clusterArray = Object.values(clusters);
    const sortedClusters = clusterArray.sort(
      (a, b) => b.totalWeight - a.totalWeight
    );

    const highDensityAreas = sortedClusters.filter(
      (cluster) => cluster.count >= 5
    ).length;
    const averageDensity =
      clusterArray.reduce((sum, cluster) => sum + cluster.count, 0) /
      clusterArray.length;

    const topAreas = sortedClusters
      .slice(0, 3)
      .map(
        (cluster, index) =>
          `${index + 1}. منطقة (${cluster.lat.toFixed(
            3
          )}, ${cluster.lon.toFixed(3)}) - ${cluster.count} حوادث`
      );

    return {
      highDensityAreas,
      averageDensity,
      topAreas:
        topAreas.length > 0 ? topAreas : ["لا توجد مناطق عالية الكثافة"],
    };
  }, []);

  // Enhanced function to find closest incidents
  const findClosestIncidents = useCallback(
    (queryLat, queryLon, queryDate = null, limit = 5) => {
      console.log(
        `🔍 Finding closest incidents to (${queryLat}, ${queryLon}) from ${allFeaturesData.length} features`
      );

      if (!allFeaturesData.length) {
        console.log("❌ No features data available");
        return [];
      }

      const incidents = allFeaturesData
        .map((feature) => {
          let lat = null,
            lon = null,
            distance = Infinity;

          // Extract coordinates based on geometry type
          if (feature.geometry) {
            switch (feature.geometry.type) {
              case "Point":
                [lon, lat] = feature.geometry.coordinates;
                break;
              case "Polygon":
              case "MultiPolygon":
                // Calculate centroid for polygons
                const coords =
                  feature.geometry.type === "Polygon"
                    ? feature.geometry.coordinates[0]
                    : feature.geometry.coordinates[0][0];
                lat =
                  coords.reduce((sum, coord) => sum + coord[1], 0) /
                  coords.length;
                lon =
                  coords.reduce((sum, coord) => sum + coord[0], 0) /
                  coords.length;
                break;
            }
          }

          if (lat !== null && lon !== null) {
            distance = calculateDistance(queryLat, queryLon, lat, lon);
          }

          // Extract date information from properties
          let incidentDate = null;
          const props = feature.properties || {};

          // Look for common date fields
          const dateFields = [
            "date",
            "incident_date",
            "timestamp",
            "created_at",
            "occurred_at",
            "report_date",
            "Acc_Time",
          ];
          for (const field of dateFields) {
            if (props[field]) {
              incidentDate = parseDate(props[field]);
              if (incidentDate) break;
            }
          }

          let timeDiff = Infinity;
          if (queryDate && incidentDate) {
            timeDiff = Math.abs(queryDate.getTime() - incidentDate.getTime());
          }

          return {
            feature,
            coordinates: [lat, lon],
            distance,
            incidentDate,
            timeDiff,
            properties: props,
          };
        })
        .filter((item) => item.distance !== Infinity);

      // Sort by distance first, then by time if dates are available
      incidents.sort((a, b) => {
        if (queryDate && a.incidentDate && b.incidentDate) {
          // If we have a query date and both incidents have dates, prioritize time
          const timeDiffA = a.timeDiff;
          const timeDiffB = b.timeDiff;
          return timeDiffA - timeDiffB;
        }
        // Otherwise sort by distance
        return a.distance - b.distance;
      });

      console.log(
        `✅ Found ${incidents.length} incidents, returning top ${limit}`
      );
      return incidents.slice(0, limit);
    },
    [allFeaturesData, calculateDistance, parseDate]
  );

  // Enhanced function to display only specific features on map
  const displayOnlyFeatures = useCallback(
    async (features, highlightColor = "#ff0000") => {
      if (!mapRef.current || !window.L || !features.length) {
        console.log(
          "❌ Cannot display features: missing map, Leaflet, or features"
        );
        return;
      }

      const L = window.L;

      try {
        // Remove existing layers
        if (geoJsonLayerRef.current) {
          mapRef.current.removeLayer(geoJsonLayerRef.current);
          geoJsonLayerRef.current = null;
        }
        if (highlightLayerRef.current) {
          mapRef.current.removeLayer(highlightLayerRef.current);
          highlightLayerRef.current = null;
        }

        // Create GeoJSON data with only the selected features
        const filteredData = {
          type: "FeatureCollection",
          features: features.map((item) => item.feature),
        };

        console.log(`🗺️ Displaying ${features.length} features on map`);

        // Create new layer with highlighted features
        const highlightedLayer = L.geoJSON(filteredData, {
          style: function (feature) {
            const isPolygon = feature.geometry.type.includes("Polygon");
            return {
              color: highlightColor,
              weight: isPolygon ? 4 : 3,
              opacity: 1,
              fillColor: highlightColor,
              fillOpacity: isPolygon ? 0.7 : 0.9,
            };
          },
          pointToLayer: function (feature, latlng) {
            return L.circleMarker(latlng, {
              radius: 12,
              fillColor: highlightColor,
              color: "#fff",
              weight: 3,
              opacity: 1,
              fillOpacity: 0.9,
            });
          },
          onEachFeature: function (feature, layer) {
            const props = feature.properties || {};
            let popupContent =
              '<div class="popup-content" style="max-width: 400px; font-family: Arial;">';
            popupContent += `<h4 style="margin: 0 0 10px 0; color: #333; text-align: center;">تفاصيل الحادث</h4>`;

            // Find the corresponding analysis data
            const analysisData = features.find(
              (item) => item.feature === feature
            );
            if (analysisData) {
              popupContent += `<div style="background: #f8f9fa; padding: 10px; border-radius: 6px; margin-bottom: 10px; border-left: 4px solid ${highlightColor};">`;
              if (analysisData.distance !== undefined) {
                popupContent += `<p style="margin: 3px 0; color: #666;"><strong>المسافة:</strong> ${analysisData.distance.toFixed(
                  2
                )} كم</p>`;
              }
              if (analysisData.incidentDate) {
                popupContent += `<p style="margin: 3px 0; color: #666;"><strong>التاريخ:</strong> ${analysisData.incidentDate.toLocaleDateString(
                  "ar-EG"
                )}</p>`;
              }
              popupContent += `</div>`;
            }

            if (Object.keys(props).length > 0) {
              const importantFields = [
                "Acc_Name",
                "Type_Ar",
                "Severity_Ar",
                "COMM_NAME_AR",
                "Category_Ar",
              ];
              popupContent += '<div style="margin-top: 10px;">';

              importantFields.forEach((field) => {
                if (props[field]) {
                  const arabicLabels = {
                    Acc_Name: "نوع الحادث",
                    Type_Ar: "التصنيف",
                    Severity_Ar: "درجة الخطورة",
                    COMM_NAME_AR: "المنطقة",
                    Category_Ar: "الفئة",
                  };
                  const label = arabicLabels[field] || field;
                  popupContent += `<p style="margin: 5px 0; padding: 3px 0; border-bottom: 1px solid #eee;"><strong>${label}:</strong> ${props[field]}</p>`;
                }
              });

              popupContent += "</div>";
            }

            popupContent += "</div>";
            layer.bindPopup(popupContent, { maxWidth: 400 });
          },
        });

        highlightLayerRef.current = highlightedLayer;
        highlightedLayer.addTo(mapRef.current);

        // Fit map to show all highlighted features
        const bounds = highlightedLayer.getBounds();
        if (bounds.isValid()) {
          mapRef.current.fitBounds(bounds, { padding: [20, 20] });
        }

        setActiveFeatures(features.length);
        console.log(
          `✅ Successfully displayed ${features.length} incidents on map`
        );
      } catch (error) {
        console.error("Failed to display features:", error);
        addMessage("bot", `❌ فشل في عرض البيانات: ${error.message}`);
      }
    },
    [mapRef, geoJsonLayerRef, highlightLayerRef, setActiveFeatures, addMessage]
  );

  // Enhanced map action handler with high-severity analysis
  const handleMapAction = useCallback(
    async (actionObj, actionId) => {
      if (processedActionsRef.current.has(actionId)) {
        console.log("Action already processed:", actionId);
        return;
      }

      processedActionsRef.current.add(actionId);

      const map = mapRef.current;
      if (!map) {
        console.log("Map action failed: map not available");
        return;
      }

      console.log("🎯 Executing map action:", actionObj);

      try {
        switch (actionObj.action) {
          case "analyze-high-severity":
            addMessage(
              "bot",
              "🚨 جاري تحليل الحوادث عالية الخطورة وتوزيعها الجغرافي...",
              { type: "system" }
            );
            await analyzeHighSeverityIncidents();
            break;

          case "create-heatmap":
            const { intensity = 0.5, radius = 25 } = actionObj;
            addMessage(
              "bot",
              "🔥 جاري إنشاء الخريطة الحرارية لتحليل كثافة الحوادث...",
              { type: "system" }
            );
            await createHeatmap(intensity, radius);
            break;

          case "find-closest-spatial":
            const { lat, lon, limit = 5 } = actionObj;
            if (lat !== undefined && lon !== undefined) {
              addMessage(
                "bot",
                `🔍 جاري البحث عن ${limit} حوادث أقرب للإحداثيات (${lat.toFixed(
                  4
                )}, ${lon.toFixed(4)})...`,
                { type: "system" }
              );

              const closestIncidents = findClosestIncidents(
                lat,
                lon,
                null,
                limit
              );

              if (closestIncidents.length > 0) {
                await displayOnlyFeatures(closestIncidents, "#e74c3c");

                const summary = closestIncidents
                  .map((incident, index) => {
                    const props = incident.properties;
                    const arabicName =
                      props.Acc_Name || props.Type_Ar || "حادث مروري";
                    const area =
                      props.COMM_NAME_AR ||
                      props.COMM_NAME_EN ||
                      "منطقة غير محددة";
                    const severity = props.Severity_Ar || "غير محدد";
                    return `${index + 1
                      }. ${arabicName}\n   📍 ${area} - المسافة: ${incident.distance.toFixed(
                        2
                      )} كم\n   🚨 الخطورة: ${severity}${incident.incidentDate
                        ? `\n   📅 التاريخ: ${incident.incidentDate.toLocaleDateString(
                          "ar-EG"
                        )}`
                        : ""
                      }`;
                  })
                  .join("\n\n");

                addMessage(
                  "bot",
                  `🎯 تم العثور على ${closestIncidents.length} حوادث أقرب مكانياً:\n\n${summary}\n\n💡 انقر على العلامات الحمراء لمزيد من التفاصيل.`
                );
              } else {
                addMessage(
                  "bot",
                  "⚠️ لم يتم العثور على حوادث في البيانات المحملة"
                );
              }
            }
            break;

          case "find-closest-temporal":
            const { date: queryDateStr, limit: tempLimit = 5 } = actionObj;
            const queryDate = parseDate(queryDateStr);

            if (queryDate) {
              addMessage(
                "bot",
                `⏰ جاري البحث عن ${tempLimit} حوادث أقرب زمنياً لتاريخ ${queryDate.toLocaleDateString(
                  "ar-EG"
                )}...`,
                { type: "system" }
              );

              const temporalIncidents = allFeaturesData
                .map((feature) => {
                  const props = feature.properties || {};
                  let incidentDate = null;

                  const dateFields = [
                    "date",
                    "incident_date",
                    "timestamp",
                    "created_at",
                    "occurred_at",
                    "report_date",
                    "Acc_Time",
                  ];
                  for (const field of dateFields) {
                    if (props[field]) {
                      incidentDate = parseDate(props[field]);
                      if (incidentDate) break;
                    }
                  }

                  if (!incidentDate) return null;

                  let lat = null,
                    lon = null;
                  if (feature.geometry) {
                    switch (feature.geometry.type) {
                      case "Point":
                        [lon, lat] = feature.geometry.coordinates;
                        break;
                      case "Polygon":
                        const coords = feature.geometry.coordinates[0];
                        lat =
                          coords.reduce((sum, coord) => sum + coord[1], 0) /
                          coords.length;
                        lon =
                          coords.reduce((sum, coord) => sum + coord[0], 0) /
                          coords.length;
                        break;
                    }
                  }

                  return {
                    feature,
                    coordinates: [lat, lon],
                    incidentDate,
                    timeDiff: Math.abs(
                      queryDate.getTime() - incidentDate.getTime()
                    ),
                    properties: props,
                  };
                })
                .filter((item) => item !== null)
                .sort((a, b) => a.timeDiff - b.timeDiff)
                .slice(0, tempLimit);

              if (temporalIncidents.length > 0) {
                await displayOnlyFeatures(temporalIncidents, "#9b59b6");

                const summary = temporalIncidents
                  .map((incident, index) => {
                    const daysDiff = Math.floor(
                      incident.timeDiff / (1000 * 60 * 60 * 24)
                    );
                    const props = incident.properties;
                    const arabicName =
                      props.Acc_Name || props.Type_Ar || "حادث مروري";
                    return `${index + 1
                      }. ${arabicName}\n   📅 ${incident.incidentDate.toLocaleDateString(
                        "ar-EG"
                      )} (فارق ${daysDiff} يوم)`;
                  })
                  .join("\n\n");

                addMessage(
                  "bot",
                  `⏰ تم العثور على ${temporalIncidents.length} حوادث أقرب زمنياً:\n\n${summary}\n\n💜 العلامات البنفسجية تظهر النتائج على الخريطة.`
                );
              } else {
                addMessage(
                  "bot",
                  "⚠️ لم يتم العثور على حوادث بتواريخ صحيحة في البيانات"
                );
              }
            } else {
              addMessage(
                "bot",
                "⚠️ لا يمكن تحليل التاريخ المعطى. استخدم صيغ مثل: 2024-01-15، 15/01/2024، أو 2024/01/15"
              );
            }
            break;

          case "clear":
            // Clear all layers and show empty map
            if (geoJsonLayerRef.current) {
              mapRef.current.removeLayer(geoJsonLayerRef.current);
              geoJsonLayerRef.current = null;
            }
            if (highlightLayerRef.current) {
              mapRef.current.removeLayer(highlightLayerRef.current);
              highlightLayerRef.current = null;
            }
            if (legendRef.current) {
              mapRef.current.removeControl(legendRef.current);
              legendRef.current = null;
            }

            setActiveFeatures(0);
            addMessage("bot", "🧹 تم مسح جميع النتائج من الخريطة", {
              type: "system",
            });
            break;

          case "filter-by-property":
            const { property, value, limit: filterLimit = 10 } = actionObj;
            if (property && value) {
              const matchingFeatures = allFeaturesData
                .filter((feature) => {
                  const props = feature.properties || {};
                  return Object.values(props).some((propValue) =>
                    String(propValue)
                      .toLowerCase()
                      .includes(String(value).toLowerCase())
                  );
                })
                .slice(0, filterLimit)
                .map((feature) => ({
                  feature,
                  coordinates:
                    feature.geometry?.type === "Point"
                      ? [
                        feature.geometry.coordinates[1],
                        feature.geometry.coordinates[0],
                      ]
                      : null,
                  distance: 0,
                  properties: feature.properties || {},
                }));

              if (matchingFeatures.length > 0) {
                await displayOnlyFeatures(matchingFeatures, "#2ecc71");
                addMessage(
                  "bot",
                  `🔍 تم العثور على ${matchingFeatures.length} حادث يحتوي على "${value}" - مُظلل بالأخضر على الخريطة.`
                );
              } else {
                addMessage(
                  "bot",
                  `⚠️ لم يتم العثور على حوادث تحتوي على "${value}"`
                );
              }
            }
            break;

          default:
            console.warn("Unhandled MAP_ACTION:", actionObj);
        }
      } catch (error) {
        console.error("Map action execution failed:", error);
        addMessage("bot", "❌ فشل في تنفيذ عملية الخريطة", { type: "system" });
      }
    },
    [
      allFeaturesData,
      findClosestIncidents,
      displayOnlyFeatures,
      parseDate,
      calculateDistance,
      createHeatmap,
      analyzeHighSeverityIncidents,
      mapRef,
      geoJsonLayerRef,
      highlightLayerRef,
      legendRef,
      processedActionsRef,
      setActiveFeatures,
      addMessage,
    ]
  );

  return {
    calculateDistance,
    parseDate,
    findClosestIncidents,
    displayOnlyFeatures,
    handleMapAction,
    createHeatmap,
    analyzeDensityClusters,
    analyzeHighSeverityIncidents,
    performGeographicClustering,
    generateSeverityAnalysisReport,
    generateSafetyRecommendations,
  };
};
